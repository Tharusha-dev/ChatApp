export const API_URL = "http://localhost:8000";

// export const API_URL_LOCAL = "http://localhost:3000/api";
